const { Schema, model } = require('mongoose');

const MascotaSchema = Schema({
    nombre: {
        type: String,
        require: [true, 'Nombre de la mascota es obligatorio']
    },
    raza: {
        type: String,
        require: [true, 'Raza de la mascota es obligatoria']
    },
    edad: {
        type: String,
        require: [true, 'La edad de la mascota es obligatoria']
    },
    estado: {
        type: String,
        default: true
    },
});

module.exports = model ('Mascota', MascotaSchema);