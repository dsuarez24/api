const { Schema, model} = require('mongoose');

const UsuarioSchema = Schema({
    nombreAnimal:{
        type: String,
        required: [true, 'El nombre debe ser obligatorio']
    },

    EspecieAnimal:{
        type: String,
        required: [true, 'El animal debe ser obligatorio']

    },

    peso: {
        type: String,
        required: [true, 'Pedo de animal debe ser obligatorio']

    }






})